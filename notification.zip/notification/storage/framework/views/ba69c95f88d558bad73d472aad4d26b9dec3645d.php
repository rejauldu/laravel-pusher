<!doctype html>
<html>
<head>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
	<div id="app"></div>
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	<script>
	Echo.channel('all-user')
    .listen('NotificationEvent', (e) => {
        console.log(e.message);
    });
</script>
</body>

</html>